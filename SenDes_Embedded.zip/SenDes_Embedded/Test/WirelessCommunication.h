#ifndef WIRELESS_COMMUNICATION_H
#define WIRELESS_COMMUNICATION_H

#include <WiFi.h>

class WirelessCommunication 
{
  private:
    const char* ssid;
    const char* password;
    const char* host;
    uint16_t port;
    WiFiClient client;

  public:
    // Constructor
    WirelessCommunication(const char* wifiSSID, const char* wifiPassword, const char* serverHost, uint16_t serverPort);

    // Connect to Wi-Fi network
    void connectWiFi();

    // Connect to the server
    bool connectToServer();

    // Send data to the server
    void sendData(const String& data);
};

#endif  // WIRELESS_COMMUNICATION_H
