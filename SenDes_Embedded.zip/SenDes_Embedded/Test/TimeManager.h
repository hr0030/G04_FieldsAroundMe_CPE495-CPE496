#ifndef TIMER_MANAGER_H
#define TIMER_MANAGER_H

#include <Arduino.h>

class TimerManager {
  private:
    hw_timer_t *timer;
    volatile SemaphoreHandle_t timerSemaphore;
    portMUX_TYPE timerMux;
    volatile bool timerFlag;
    unsigned long TickCounter;
    unsigned long msTimer;
    unsigned long secTimer;
    
  public:
    // Constructor and Destructor
    TimerManager();
    ~TimerManager();

    // Initialize and configure the timer
    void setupTimer(uint32_t msInterval);

    // ISR function for handling timer interrupt
    static void IRAM_ATTR onTimer();

    // Flag to indicate timer firing status
    bool isTimerFired();

    // Reset timer flag
    void resetTimerFlag();

    // Optional utility functions
    unsigned long getTickCount();
    unsigned long getMsTimer();
    unsigned long getSecTimer();
};

#endif  // TIMER_MANAGER_H
