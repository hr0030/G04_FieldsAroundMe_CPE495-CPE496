#include "ADCController.h"

ADCController::ADCController(uint32_t adcTimeout) : timeout(adcTimeout) {}

ADCController::~ADCController() {}

bool ADCController::initialize() {
  int slave_select = 19;  // Set the correct Chip Select pin for your ADC
  if (adc.begin(slave_select) != 0) {
    Serial.println("ADC Initialization Failed!");
    return false;
  }

  adc.setAdcControl(Ad7124::ContinuousMode, Ad7124::FullPower, true, Ad7124::ExternalClk);
  adc.setTimeout(timeout);

  return true;
}

bool ADCController::configureChannel(int channel, uint8_t setup, Ad7124::InputSel ainp, Ad7124::InputSel ainm) {
  if (adc.setChannel(channel, setup, ainp, ainm, true) != 0) {
    Serial.print("Failed to configure channel ");
    Serial.println(channel);
    return false;
  }
  adc.setConfig(setup, Ad7124::RefInternal, Ad7124::Pga1, true, Ad7124::BurnoutOff);
  adc.setConfigFilter(setup, Ad7124::Sinc4Filter, Ad7124::dB86PostFilter, 1024, true, false);
  return true;
}

long ADCController::readChannel(int channel) {
  adc.startSingleConversion(channel);  // Start conversion on specified channel
  adc.waitEndOfConversion(1000);  // Wait for conversion (timeout in ms)
  return adc.getData();  // Retrieve sample
}

double ADCController::sampleToVoltage(long sample, int gain, double vref) {
  return Ad7124Chip::toVoltage(sample, gain, vref, true);  // Convert to voltage
}
