#include "TimerManager.h"

TimerManager::TimerManager()
  : timer(nullptr), timerSemaphore(xSemaphoreCreateBinary()), timerMux(portMUX_INITIALIZER_UNLOCKED),
    timerFlag(false), TickCounter(0), msTimer(0), secTimer(0) {}

TimerManager::~TimerManager() {
  if (timer) {
    timerEnd(timer);
  }
  if (timerSemaphore) {
    vSemaphoreDelete(timerSemaphore);
  }
}

void TimerManager::setupTimer(uint32_t msInterval) {
  timer = timerBegin(0, 80, true);  // 80 prescaler for 1µs tick on ESP32
  timerAttachInterrupt(timer, &TimerManager::onTimer, true);
  timerAlarmWrite(timer, msInterval * 1000, true);
  timerAlarmEnable(timer);
}

void IRAM_ATTR TimerManager::onTimer() {
  static portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;
  portENTER_CRITICAL_ISR(&timerMux);

  TimerManager* self = (TimerManager*)nullptr;  // Resolve static member call within ISR

  self->timerFlag = true;
  self->TickCounter++;
  if (self->TickCounter >= 200) { // Ticks per second, if MS_INT is set to 5ms
    self->TickCounter = 0;
    self->secTimer++;
  }
  self->msTimer += 5;  // Adjust msTimer based on interval if needed

  portEXIT_CRITICAL_ISR(&timerMux);
  xSemaphoreGiveFromISR(self->timerSemaphore, NULL);
}

bool TimerManager::isTimerFired() {
  return timerFlag;
}

void TimerManager::resetTimerFlag() {
  timerFlag = false;
}

unsigned long TimerManager::getTickCount() {
  return TickCounter;
}

unsigned long TimerManager::getMsTimer() {
  return msTimer;
}

unsigned long TimerManager::getSecTimer() {
  return secTimer;
}
