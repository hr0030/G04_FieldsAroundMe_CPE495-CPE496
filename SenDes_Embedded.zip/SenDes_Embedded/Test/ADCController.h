#ifndef ADC_CONTROLLER_H
#define ADC_CONTROLLER_H

#include <Arduino.h>
#include <ad7124.h>  // Include the specific ADC library

class ADCController {
  private:
    Ad7124Chip adc;
    uint32_t timeout;  // Timeout for ADC IO operations
    
  public:
    // Constructor and Destructor
    ADCController(uint32_t adcTimeout = 2000);
    ~ADCController();

    // Initialize ADC and configure channels
    bool initialize();

    // Configure a single channel
    bool configureChannel(int channel, uint8_t setup, Ad7124::InputSel ainp, Ad7124::InputSel ainm);

    // Start single conversion on a specified channel and retrieve data
    long readChannel(int channel);

    // Convert ADC sample to voltage
    double sampleToVoltage(long sample, int gain = 1, double vref = 2.5);
};

#endif  // ADC_CONTROLLER_H
