#include "WirelessCommunication.h"

WirelessCommunication::WirelessCommunication(const char* wifiSSID, const char* wifiPassword, const char* serverHost, uint16_t serverPort)
  : ssid(wifiSSID), password(wifiPassword), host(serverHost), port(serverPort) {}

void WirelessCommunication::connectWiFi() {
  Serial.print("Connecting to WiFi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("Connected to WiFi");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

bool WirelessCommunication::connectToServer() {
  Serial.print("Connecting to server...");
  
  if (client.connect(host, port)) {
    Serial.println("Connected to server");
    return true;
  } else {
    Serial.println("Connection to server failed");
    return false;
  }
}

void WirelessCommunication::sendData(const String& data) {
  if (client.connected()) {
    client.println(data);
    Serial.println("Data sent to server");
  } else {
    Serial.println("Disconnected from server, attempting reconnect...");
    connectToServer();
  }
}
