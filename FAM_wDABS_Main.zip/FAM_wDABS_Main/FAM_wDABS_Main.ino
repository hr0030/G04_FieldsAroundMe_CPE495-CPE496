// FAM wDABS Embedded Code
// Writers: Jacob Dodd & Hayden Rose
// Mentor: Dr. Emil Jovanov
// CPE Senior Design F24-S25

/******************************************
*                INCLUDES               *
******************************************/
#include <Arduino.h>       // Standard Arduino core
#include <SPI.h>           // SPI library 
#include <WiFi.h>          // WiFi support
#include <ArduinoMqttClient.h>
#include <HardwareSerial.h> // For UART (OpenLog)
#include "AD_Defs.h"       // ADC Definitions 
#include <WiFiUdp.h>
#include <NTPClient.h>
#include <Ticker.h>
#include <FreeRTOS.h> 
#include <semphr.h>
#include <vector>
#include <queue>

/******************************************
*            WIFI CONFIGURATION          *
******************************************/
const char* ssid = "Student5";         // Wi-Fi SSID
const char* password = "Go Chargers!"; // Wi-Fi Password

/******************************************
*            MQTT CONFIGURATION          *
******************************************/

const char* mqtt_server = "10.4.175.17";  
const int mqtt_port = 1883;               
WiFiClient wifiClient;
MqttClient mqttClient(wifiClient);
bool mqttConnected = false;

/******************************************
*          DEFINITIONS & MACROS         *
******************************************/
#define ENABLE_MULTI_CHANNELS  // Comment out to disable multi-channel functionality
uint16_t fs = 18;   // 48 = 100Hz, 18 = 250Hz  

#define NUM_CHANNELS 4  // Number of ADC channels
std::queue<int32_t> adcBuffer[NUM_CHANNELS];  // Queue for each channel
std::queue<uint8_t> channelQueue;  // Queue for keeping track of correct channel order


// UART Configurations for OpenLog.
#define UART_PORT_NUM      1    
#define UART_BAUD_RATE     9600
#define UART_TX_PIN        39   // TX pin for OpenLog
#define UART_RX_PIN        38   // RX pin for OpenLog
#define OPENLOG_RESET_PIN  14   // Reset pin for OpenLog
#define BUF_SIZE           1024

// SPI Configuration
#define SPI_MISO_PIN    37      
#define SPI_MOSI_PIN    35   
#define SPI_SCLK_PIN    36   
#define SPI_CS_PIN      8   

// MQTT Client and Connection Status
WiFiClient espClient;
uint8_t txData[4] = {0};  // Data Buffer

// NTP Client Configuration
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", 0, 60000); // NTP server, UTC, update every 60 seconds

SemaphoreHandle_t adc_semaphore;
Ticker adcTimer;
uint64_t last_time = 0;
char Current_Date_Time[20]; // For timestamping logs

/****************************
*      UART FUNCTIONS      *
****************************/
HardwareSerial OpenLog(UART_PORT_NUM); // Create a HardwareSerial instance for OpenLog

void openlog_uart_init()  // Initialize UART for OpenLog communication
{
  OpenLog.begin(UART_BAUD_RATE, SERIAL_8N1, UART_RX_PIN, UART_TX_PIN);
  Serial.println("OpenLog UART initialized.");
}

void reset_openlog()  // Reset OpenLog before data logging
{
  pinMode(OPENLOG_RESET_PIN, OUTPUT);
  Serial.println("Resetting OpenLog...");
  digitalWrite(OPENLOG_RESET_PIN, LOW);  // Assert reset (low)
  delay(100); // Hold for 100 ms
  digitalWrite(OPENLOG_RESET_PIN, HIGH); // Deassert reset (high)
  delay(100); // Wait for OpenLog to initialize
  Serial.println("OpenLog reset complete.");
}

void log_to_openlog(const char *log_line) // Log ADC data to OpenLog
{
  OpenLog.print(log_line);
  //Serial.print("Logged to OpenLog: ");  // Uncomment if you want to see the output of the openlog during runtime
  Serial.println(log_line);
}

/******************************************
*          SPI CONFIG FUNCTIONS         *
******************************************/

SPIClass spi = SPIClass(FSPI); // Use FSPI bus on ESP32-S3

void spi_init() // Initialize SPI 
{
  spi.begin(SPI_SCLK_PIN, SPI_MISO_PIN, SPI_MOSI_PIN, SPI_CS_PIN); 
  pinMode(SPI_CS_PIN, OUTPUT); 
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect the device
  Serial.println("SPI Initialized");
}

int spiRead(uint8_t *txBuffer, uint8_t *rxBuffer, size_t len) // SPI Read Function
{
  digitalWrite(SPI_CS_PIN, LOW);  // Select the device
  for (size_t i = 0; i < len; i++) 
  {
    rxBuffer[i] = spi.transfer(txBuffer[i]); // Perform SPI transfer
  }
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect the device

  //Serial.print("SPI Read: ");
  for (size_t i = 0; i < len; i++) 
  {
    //Serial.printf("0x%02X ", rxBuffer[i]);
  }
  Serial.println();
    
  return 0; 
}

int spiWrite(uint8_t *txBuffer, size_t len) // SPI Write Function
{
  digitalWrite(SPI_CS_PIN, LOW);  // Select the device
  for (size_t i = 0; i < len; i++) 
  {
      spi.transfer(txBuffer[i]); // Send each byte
  }
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect the device
    
  //Serial.println("SPI Write Complete");
  return 0; 
}

/******************************************
*           ADC CONTROL FUNCTIONS       *
******************************************/

void ADC_reset()  // Reset ADC
{
  uint8_t wr_buf[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  spiWrite(wr_buf, sizeof(wr_buf)); // Send reset sequence
  Serial.println("ADC Reset Sent");
}

int adcWrite(uint8_t reg, uint8_t *data, size_t len)  // Write to ADC Register
{
  uint8_t txBuffer[len + 1];
  txBuffer[0] = AD7124_COMM_REG_WR | AD7124_COMM_REG_RA(reg); // Command byte
  memcpy(&txBuffer[1], data, len); // Copy data into buffer

  return spiWrite(txBuffer, len + 1); // Write buffer over SPI
}

int adcRead(uint8_t reg, uint8_t *data, size_t len)
{
  uint8_t txBuffer[1] = { (uint8_t)(AD7124_COMM_REG_RD | (uint8_t)AD7124_COMM_REG_RA(reg)) }; // Fix narrowing conversion
  uint8_t rxBuffer[len + 1]; // Extra byte for command echo

  digitalWrite(SPI_CS_PIN, LOW);  // Select ADC
  spi.transfer(txBuffer[0]);      // Send read command
  for (size_t i = 0; i < len; i++) 
  {
    rxBuffer[i] = spi.transfer(0x00); // Read response
  }
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect ADC

  memcpy(data, &rxBuffer[0], len); // Copy only received data

  return 0; // Success
}

void readAndBufferData() 
{
  static uint8_t lastChannel = 0xFF;  // Keep track of last channel read
  uint8_t status = 0;
  int32_t adcValue = 0;

  // Read the status register to get the current active channel
  adcRead(AD7124_STATUS_REG, &status, 1);
  uint8_t currentChannel = status & 0x0F;  // Extract active channel ID

  // Check if the channel has changed before processing
  if (currentChannel == lastChannel) 
  {
    return;  // Ignore if ADC hasn't moved to the next channel
  }

  lastChannel = currentChannel;  // Update last channel read

  // Read the ADC Data Register
  uint8_t dataTx[1] = {AD7124_COMM_REG_RD | AD7124_COMM_REG_RA(AD7124_DATA_REG)};
  uint8_t dataRx[4] = {0};

  int ret = spiRead(dataTx, dataRx, sizeof(dataRx));
  if (ret != 0) 
  {
    Serial.println("SPI Read Error");
    return;
  }

  // Store the 24-bit ADC value
  adcValue = (dataRx[1] << 16) | (dataRx[2] << 8) | dataRx[3];

  // Push the data into the buffer for the correct channel
  if (currentChannel < NUM_CHANNELS) 
  {
    adcBuffer[currentChannel].push(adcValue);
    channelQueue.push(currentChannel);
  }

  delayMicroseconds(50);  // Small delay for throughput time
}

double toVoltage(long value, int gain, double vref, bool bipolar) 
{
  double voltage = (double)value;
  if (bipolar) 
  {
    voltage = voltage / (double)0x7FFFFF - 1.0; // Bipolar mode: normalize ADC value to [-REF, REF]
  } 
  else 
  {
    voltage = voltage / (double)0xFFFFFF; // Unipolar mode: normalize ADC value to [0, REF]
  }

  // Apply reference voltage and gain scaling
  voltage = voltage * vref / (double)gain;
  return voltage;
}

int setAdcControl(uint8_t mode, uint8_t power, uint8_t clkSource, bool enable)
{
  uint16_t control = 0;

  control |= AD7124_ADC_CTRL_REG_MODE(mode);
  control |= AD7124_ADC_CTRL_REG_POWER_MODE(power);
  control |= AD7124_ADC_CTRL_REG_CLK_SEL(clkSource);
  if (enable) 
  {
    control |= AD7124_ADC_CTRL_REG_REF_EN;
  }
  control |= AD7124_ADC_CTRL_REG_CS_EN;

  uint8_t controlBytes[2] = { (uint8_t)(control >> 8), (uint8_t)(control & 0xFF) };
  return adcWrite(AD7124_ADC_CTRL_REG, controlBytes, 2);
}

int setConfig(uint8_t configNum, uint8_t reference, uint8_t gain, bool bipolar)
{
  uint16_t config = 0;

  config |= AD7124_CFG_REG_REF_SEL(reference);
  config |= AD7124_CFG_REG_PGA(gain);
  if (bipolar) 
  {
    config |= AD7124_CFG_REG_BIPOLAR;
  }

  uint8_t configBytes[2] = { (uint8_t)(config >> 8), (uint8_t)(config & 0xFF) };
  return adcWrite(AD7124_CFG0_REG + configNum, configBytes, 2);
}

int setConfigFilter(uint8_t filterNum, uint8_t filterType, uint16_t targetSPS, bool enableRej60)
{
  uint32_t filter = 0;
  filter |= AD7124_FILT_REG_FILTER(filterType); // Sinc4 filter

  if (enableRej60) 
  {
    filter |= AD7124_FILT_REG_REJ60;  // Enable 60 Hz rejection
  }
  filter |= AD7124_FILT_REG_FS(fs);

  // Create filter configuration bytes
  uint8_t filterBytes[3] = {
    (uint8_t)((filter >> 16) & 0xFF),
    (uint8_t)((filter >> 8) & 0xFF),
    (uint8_t)(filter & 0xFF)
  };

  // Write the configuration to the appropriate filter register
  return adcWrite(AD7124_FILT0_REG + filterNum, filterBytes, 3);
}

int setChannel(uint8_t channelNum, uint8_t configNum, uint8_t posInput, uint8_t negInput, bool enable)
{
  uint16_t channel = 0;

  channel |= AD7124_CH_MAP_REG_SETUP(configNum);
  channel |= AD7124_CH_MAP_REG_AINP(posInput);
  channel |= AD7124_CH_MAP_REG_AINM(negInput);
  if (enable) 
  {
    channel |= AD7124_CH_MAP_REG_CH_ENABLE;
  }

  uint8_t channelBytes[2] = { (uint8_t)(channel >> 8), (uint8_t)(channel & 0xFF) };
  int status = adcWrite(AD7124_CH0_MAP_REG + channelNum, channelBytes, 2);

  Serial.printf("Channel %d set status: %d\n", channelNum, status);
  return status;
}


int enableChannel(uint8_t channelNum, bool enable)
{
  uint8_t channelBytes[2] = {0};
  int status = adcRead(AD7124_CH0_MAP_REG + channelNum, channelBytes, 2);
  if (status != 0) 
  {
    return status;
  }

  uint16_t channel = (channelBytes[0] << 8) | channelBytes[1];
  if (enable) 
  {
    channel |= AD7124_CH_MAP_REG_CH_ENABLE; // Enable the channel
  } 
  else 
  {
    channel &= ~AD7124_CH_MAP_REG_CH_ENABLE; // Disable the channel
  }

  channelBytes[0] = (uint8_t)((channel >> 8) & 0xFF);
  channelBytes[1] = (uint8_t)(channel & 0xFF);

  return adcWrite(AD7124_CH0_MAP_REG + channelNum, channelBytes, 2);
}

void ad7124_init(uint16_t target_sps)
{
  // Configure ADC control
  int status = setAdcControl(0x00, 0x03, 0x00, false); // Continuous, full power, internal clock, REF_EN = false
  Serial.printf("ADC control set status: %d\n", status);

  // Set default configuration for input channel(s)
  status = setConfig(0, 0x00, 0x00, true); // Config 0, REF1- & REF1+, Gain=1, Unipolar = False, Bipolar = True
  Serial.printf("ADC config set status: %d\n", status);

  // Calculate Filter Word (FS) for target SPS
  status = setConfigFilter(0, 0x00, target_sps, true); // Sinc4 filter with target SPS and 60Hz Notch Enabled
  Serial.printf("ADC filter set status: %d\n", status);

  // Configure and enable channels
  status = setChannel(0, 0, 0x00, 0x01, true); // Channel 0: AIN0(+) to AIN1(-)
  Serial.printf("Channel 0 set status: %d\n", status);

  #ifdef ENABLE_MULTI_CHANNELS
    // Configure and enable Channel 1 (AIN2 & AIN3)
    status = setChannel(1, 0, 0x02, 0x03, true);
    Serial.printf("Channel 1 set status: %d\n", status);

    // Configure and enable Channel 2 (AIN4 & AIN5)
    status = setChannel(2, 0, 0x04, 0x05, true);
    Serial.printf("Channel 2 set status: %d\n", status);

    // Configure and enable Channel 3 (AIN6 & AIN7)
    status = setChannel(3, 0, 0x06, 0x07, true);
    Serial.printf("Channel 3 set status: %d\n", status);
  #endif

  // Disable unused channels
  for (int i = 4; i < 8; i++) 
  {
    status = enableChannel(i, false);
    Serial.printf("Channel %d disable status: %d\n", i, status);
  }
}

// Connect to Wi-Fi
void wifi_init() 
{
  Serial.print("Connecting to Wi-Fi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    Serial.print(".");  // IF YOU SEE A SERIES OF ...... ON COMPILE, YOUR WIFI PROBABLY ISNT CONNECTED. CHECK YOUR INFO
  }

  Serial.println("\nWi-Fi connected.");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
}

void checkWiFi()  // Handle Wi-Fi Reconnection  
{
  if (WiFi.status() != WL_CONNECTED) 
  {
    Serial.println("Reconnecting to Wi-Fi...");
    WiFi.disconnect();
    WiFi.reconnect();
  }
}

// Initialize SNTP (NTP Time Sync)
void init_SNTP()
{
  Serial.println("Initializing SNTP Link...");
  timeClient.begin();
}

// Obtain current time from NTP server
void obtain_time()
{
  init_SNTP();
    
  int retry = 0;
  const int retry_count = 10;
    
  while (!timeClient.update() && retry < retry_count) 
  {
    Serial.printf("Waiting for TimeSync... (%d|%d)\n", retry + 1, retry_count);
    retry++;
    delay(2000);
  }

  if (retry >= retry_count) 
  {
    Serial.println("Failed to sync time!");
  }
}

void Get_current_date_time(char *date_time)
{
  timeClient.update(); // Ensure time is updated

  time_t epochTime = timeClient.getEpochTime(); // Get epoch time
  struct tm *timeinfo = localtime(&epochTime); // Convert to local time structure

  snprintf(date_time, 100, "%04d-%02d-%02d %02d:%02d:%02d",
  timeinfo->tm_year + 1900, timeinfo->tm_mon + 1, timeinfo->tm_mday,
  timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
}

void Set_SystemTime_SNTP()  // Set system time using SNTP
{
  timeClient.update(); // Ensure we get the latest time

  if (timeClient.getEpochTime() < 1483228800) // Check if time is valid (2017-01-01 00:00:00 UTC)
  {
    Serial.println("Time not set! Attempting to Re-Sync...");
    obtain_time();
  }
}

void IRAM_ATTR adc_timer_callback() 
{
  static uint64_t last_interrupt_time = 0;
  uint64_t current_interrupt_time = micros();

  //Serial.printf("Interrupt Fired! deltat = %llu us\n", current_interrupt_time - last_interrupt_time);
  last_interrupt_time = current_interrupt_time;

  xSemaphoreGiveFromISR(adc_semaphore, NULL);
}

// Setup ADC Timer
void setup_adc_timer(uint64_t interval_us) 
{
  adcTimer.attach_us(interval_us, adc_timer_callback); // Set periodic timer
  Serial.printf("ADC Timer set to %llu us interval\n", interval_us);
}

/******************************************
*           MQTT FUNCTIONS               *
******************************************/

void mqttStart() // MQTT Initialization
{

  Serial.println("Connecting to MQTT Broker...");

  if (!mqttClient.connect(mqtt_server, mqtt_port))
  {
    Serial.println("MQTT connection failed!");
    return;
  }

  Serial.println("Connected to MQTT Broker!");
  mqttConnected = true;
  
  mqttClient.subscribe("esp32/sensor/data");  // Subscribe to topic
}

void mqttPublish(int channel, double voltage)  // Publish message to MQTT Broker
{
  if (!mqttConnected) 
  {
    Serial.println("MQTT not connected, skipping publish");
    return;
  }

  char message[50];
  snprintf(message, sizeof(message), "Channel %d: %g V", channel, voltage);
  
  mqttClient.beginMessage("esp32/sensor/data");
  mqttClient.print(message);
  mqttClient.endMessage();

  Serial.printf("Published to MQTT: %s\n", message);
}

/******************************************
*            SETUP & MAIN LOOP           *
******************************************/

void processBufferedData() 
{
  while (!channelQueue.empty()) 
  {
    uint8_t channel = channelQueue.front();
    channelQueue.pop();

    if (!adcBuffer[channel].empty()) 
    {
      int32_t adcValue = adcBuffer[channel].front();
      adcBuffer[channel].pop();

      double voltage = toVoltage(adcValue, 1, 3.0, true); // Convert ADC value to voltage
      Get_current_date_time(Current_Date_Time); // Grab timestamp

      uint8_t displayed_channel = channel + 1; // Convert 0-3 to 1-4 for readability

      // Prepare compressed data
      uint8_t compressed_data[4];  
      compressed_data[0] = displayed_channel;  // Store adjusted channel number

      if (channel == 0) 
      {
        // Channel 1: Keep full 24-bit data
        compressed_data[1] = (adcValue >> 16) & 0xFF;
        compressed_data[2] = (adcValue >> 8) & 0xFF;
        compressed_data[3] = adcValue & 0xFF;
      } 
      else 
      {
        // Channels 2-4: Keep only MSB (8-bit compression)
        compressed_data[1] = (adcValue >> 16) & 0xFF;
      }

      char log_line[150];
      if (channel == 0) 
      {
        snprintf(log_line, sizeof(log_line), "%s, CH%d, %02X %02X %02X, %.6f V\n", 
        Current_Date_Time, displayed_channel, compressed_data[1], compressed_data[2], compressed_data[3], voltage);
      } 
      else 
      {
        snprintf(log_line, sizeof(log_line), "%s, CH%d, %02X, %.6f V\n", 
        Current_Date_Time, displayed_channel, compressed_data[1], voltage);
      }
      log_to_openlog(log_line); // Log data to OpenLog

      if (mqttConnected) // Send over MQTT 
      {
        char mqtt_message[50];

        if (channel == 0) // Full 24-bit data for channel 1 
        {
          snprintf(mqtt_message, sizeof(mqtt_message), "CH%d:%02X%02X%02X", 
          displayed_channel, compressed_data[1], compressed_data[2], compressed_data[3]);
        } 
        else  // Only MSB for channels 2-4 
        {
          snprintf(mqtt_message, sizeof(mqtt_message), "CH%d:%02X", displayed_channel, compressed_data[1]);
        }

        mqttClient.beginMessage("esp32/sensor/data");
        mqttClient.print(mqtt_message);
        mqttClient.endMessage();

        Serial.printf("Published to MQTT: %s\n", mqtt_message);
      }
    }
  }
}

void setup() 
{
  Serial.begin(115200);
  delay(100);
  Serial.println("Starting wDABS Setup...");
  
  wifi_init();    // Initialize Wi-Fi
  delay(2000);

  Set_SystemTime_SNTP();    // Sync Chip Time to NTP Server Time
  delay(50);

  mqttStart(); // Initialize MQTT. Uncomment for testing
  delay(50);

  spi_init();   // Initialize SPI Connection 
  delay(50);

  ADC_reset();    // Reset the ADC before read operation
  delay(50);

  ad7124_init(fs);  // Initialize the ADC Registers
  delay(50);

  reset_openlog();  // Reset Openlog 
  openlog_uart_init();  // Initialize UART and Openlog

  Serial.println("wDABS Setup Complete!");
  const double f_master = 614400.0; 
  double fADC = f_master / (32.0 * fs);   
  int enabled_channels = 4;  
  double per_channel_sps = fADC / enabled_channels; 
  uint64_t sample_period_us = (uint64_t)(1000000.0 / per_channel_sps);
  adc_semaphore = xSemaphoreCreateBinary(); // Set the ADC Semaphore
  setup_adc_timer(sample_period_us); // ADC Timer for testing sampling speed
  last_time = micros();
}

void loop() 
{
  if (xSemaphoreTake(adc_semaphore, portMAX_DELAY) == pdTRUE) 
  {
    readAndBufferData();  // Read and store in FIFO buffer
    processBufferedData();  // Process stored data and log
  }
}
