// FAM wDABS Embedded Code
// Writers: Jacob Dodd, Steven Puckett, Hayden Rose
// Mentor: Dr. Emil Jovanov
// CPE Senior Design F24-S25

/******************************************
*                INCLUDES               *
******************************************/

#include <Arduino.h>       
#include <SPI.h>           
#include <WiFi.h>          
#include <ArduinoMqttClient.h>
#include <HardwareSerial.h> 
#include "AD_Defs.h"        
#include <NTPClient.h>
#include <Ticker.h>
#include <semphr.h>
#include <queue>
#include <Ticker.h>
#include "driver/gptimer.h"
#include "esp_wifi.h"
#include "esp_timer.h"
#include "sys/time.h"

/******************************************
*            WIFI CONFIGURATION          *
******************************************/
const char* ssid = "Student5";         // Wi-Fi SSID
const char* password = "Go Chargers!";   // Wi-Fi Password

/******************************************
*            MQTT CONFIGURATION          *
******************************************/

const char* mqtt_server = "10.4.171.239";  
const int mqtt_port = 1883;               
WiFiClient wifiClient;
MqttClient mqttClient(wifiClient);
bool mqttConnected = false;
Ticker mqttReconnectTicker; // Timer for MQTT reconnection


/******************************************
*          TSF SYNC CONSTANTS           *
******************************************/

gptimer_handle_t adc_gptimer = NULL; // GPTimer handle for sampling trigger
gptimer_handle_t tsfTimer     = NULL;  // the new TSF‐sync timer
int64_t tsf_now = 0, local_start = 0;
int64_t sync_tsf_0 = 0;
int64_t sync_clock_0 = 0;
float alpha = 0.0;

/******************************************
*          DEFINITIONS & MACROS         *
******************************************/

#define ENABLE_MULTI_CHANNELS  // Comment out to disable multi-channel functionality
volatile uint16_t fs = 15;  // 15 = 100Hz, 5 = 250Hz
volatile bool freqChangeRequested = false;
volatile uint16_t newRequestedFs = 48;

#define NUM_CHANNELS 4  // Number of ADC channels
#define BLOCK_SIZE 32   // Number of samples per block
#define RING_BUFFER_SIZE 4096  // Adjust as needed for throughput

int32_t adcRingBuffer[NUM_CHANNELS][RING_BUFFER_SIZE];  // Ring buffer data structures
volatile uint8_t ringHead[NUM_CHANNELS] = {0};
volatile uint8_t ringTail[NUM_CHANNELS] = {0};
uint8_t blockIndex[NUM_CHANNELS] = {0};  // Tracks current sample index within the block
volatile int32_t lastRawADC[NUM_CHANNELS] = {0};   // Holds most‑recent sample per channel
uint8_t calibrationChannel = 0;  // 0…NUM_CHANNELS-1

// UART Configurations for OpenLog.
#define UART_PORT_NUM      1    
#define UART_BAUD_RATE     115200 // If you change this, be sure to change it in the openlog config.txt also. 115200 is the highest it will go without garbage data
#define UART_TX_PIN        39   // TX pin for OpenLog
#define UART_RX_PIN        38   // RX pin for OpenLog
#define OPENLOG_RESET_PIN  14   // Reset pin for OpenLog
#define BUF_SIZE           1024

// SPI Configuration
#define SPI_MISO_PIN    37      
#define SPI_MOSI_PIN    35   
#define SPI_SCLK_PIN    36   
#define SPI_CS_PIN      8   

// NTP Client Configuration
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", 0, 1200000); // NTP server, UTC, update every 60 seconds
static int64_t offset_us = 0;    // TSF_time − micros() at last sync
SemaphoreHandle_t adc_semaphore;
Ticker adcTimer;
uint64_t last_time = 0;
char Current_Date_Time[64]; // For timestamping logs
uint32_t timestampRingBuffer[NUM_CHANNELS][RING_BUFFER_SIZE];

static const double slope[4]     = { -1.9701318583e-08, -3e-07, 2e07, -5e06 };
static const double intercept[4] = { 1.7648920968e-01, 2.8706, 7e06, 8e06 };

double calibratedVoltage(uint8_t ch, int32_t raw) 
{
  return raw * slope[ch] + intercept[ch];
}

/****************************
*      UART FUNCTIONS      *
****************************/
HardwareSerial OpenLog(UART_PORT_NUM); // Create a HardwareSerial instance for OpenLog

void openlog_uart_init()  // Initialize UART for OpenLog communication
{
  OpenLog.begin(UART_BAUD_RATE, SERIAL_8N1, UART_RX_PIN, UART_TX_PIN);
  Serial.println("OpenLog UART initialized.");
}

void reset_openlog()  // Reset OpenLog before data logging
{
  pinMode(OPENLOG_RESET_PIN, OUTPUT);
  Serial.println("Resetting OpenLog...");
  digitalWrite(OPENLOG_RESET_PIN, LOW);  // Assert reset (low)
  delay(100); // Hold for 100 ms
  digitalWrite(OPENLOG_RESET_PIN, HIGH); // Deassert reset (high)
  delay(100); // Wait for OpenLog to initialize
  Serial.println("OpenLog reset complete.");
}

void toOpenlog(const char *log_line) // Log ADC data to OpenLog
{
  OpenLog.print(log_line);
  //Serial.println("Logged to OpenLog: ");  // Uncomment if you want to see the output of the openlog during runtime
  //Serial.println(log_line);
}

/******************************************
*          SPI & CONFIG FUNCTIONS        *
******************************************/

SPIClass spi = SPIClass(FSPI); // Use FSPI bus on ESP32-S3

void spi_init() // Initialize SPI 
{
  spi.begin(SPI_SCLK_PIN, SPI_MISO_PIN, SPI_MOSI_PIN, SPI_CS_PIN); 
  pinMode(SPI_CS_PIN, OUTPUT); 
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect the device
  Serial.println("SPI Initialized");
}

int spiRead(uint8_t *txBuffer, uint8_t *rxBuffer, size_t len) // SPI Read Function
{
  digitalWrite(SPI_CS_PIN, LOW);  // Select the device
  for (size_t i = 0; i < len; i++) 
  {
    rxBuffer[i] = spi.transfer(txBuffer[i]); // Perform SPI transfer
  }
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect the device

  /*Serial.print("SPI Read: ");
  for (size_t i = 0; i < len; i++) 
  {
    //Serial.printf("0x%02X ", rxBuffer[i]);  // uncomment to see what SPI is reading in at the given moment
  }
  Serial.println();*/
    
  return 0; 
}

int spiWrite(uint8_t *txBuffer, size_t len) // SPI Write Function
{
  digitalWrite(SPI_CS_PIN, LOW);  // Select the device
  for (size_t i = 0; i < len; i++) 
  {
      spi.transfer(txBuffer[i]); // Send each byte
  }
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect the device
    
  //Serial.println("SPI Write Complete");
  return 0; 
}

/******************************************
*           ADC CONTROL FUNCTIONS       *
******************************************/
void ADC_reset()
{
  uint8_t wr_buf[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  spiWrite(wr_buf, sizeof(wr_buf)); // Send reset sequence
  Serial.println("ADC Reset Sent");
}

int adcWrite(uint8_t reg, uint8_t *data, size_t len)  // Write to ADC Register
{
  uint8_t txBuffer[len + 1];  // account for dummy byte
  txBuffer[0] = AD7124_COMM_REG_WR | AD7124_COMM_REG_RA(reg); // Command byte
  memcpy(&txBuffer[1], data, len); // Copy data into buffer

  return spiWrite(txBuffer, len + 1); // Write buffer over SPI
}

int adcRead(uint8_t reg, uint8_t *data, size_t len)
{
  uint8_t txBuffer[1] = { (uint8_t)(AD7124_COMM_REG_RD | (uint8_t)AD7124_COMM_REG_RA(reg)) }; // Fix narrowing conversion
  uint8_t rxBuffer[len + 1]; // Extra byte for command echo

  digitalWrite(SPI_CS_PIN, LOW);  // Select ADC
  spi.transfer(txBuffer[0]);      // Send read command
  for (size_t i = 0; i < len; i++) 
  {
    rxBuffer[i] = spi.transfer(0x00); // Read response
  }
  digitalWrite(SPI_CS_PIN, HIGH); // Deselect ADC

  memcpy(data, &rxBuffer[0], len); // Copy only received data

  return 0; // Success
}

void readAndBufferData() 
{
  static uint8_t lastChannel = 0xFF;
  uint8_t status = 0;
  int32_t adcValue = 0;

  // ── Wait for DRDY = 0 (conversion ready) ──
  // Bit-7 of status is DRDY (1 = busy, 0 = data ready)
  do {
    adcRead(AD7124_STATUS_REG, &status, 1);
    // tiny pause so we don’t hammer SPI
    delayMicroseconds(15);
  } while (status & 0x80);

  uint8_t ch = status & 0x0F;  // low nibble = channel

  // ── Now read the 24-bit result ──
  uint8_t cmd   = AD7124_COMM_REG_RD | AD7124_COMM_REG_RA(AD7124_DATA_REG);
  uint8_t dataRx[4] = {0};
  if (spiRead(&cmd, dataRx, sizeof(dataRx)) != 0) {
    Serial.println("SPI Read Error");
    return;
  }

  adcValue = (int32_t(dataRx[1]) << 16)
           | (int32_t(dataRx[2]) <<  8)
           | (int32_t(dataRx[3]));

  // ── Push into your ring buffer as before ──
  if (ch < NUM_CHANNELS) {
    lastRawADC[ch] = adcValue;
    uint8_t nh = (ringHead[ch] + 1) % RING_BUFFER_SIZE;
    if (nh != ringTail[ch]) {
      adcRingBuffer[ch][ringHead[ch]] = adcValue;
      ringHead[ch] = nh;
    }
  }
  //delayMicroseconds(100);
}

double toVoltage(long value, int gain, double vref, bool bipolar) 
{
  double voltage = (double)value;
  if (bipolar) 
  {
    voltage = voltage / (double)0x7FFFFF - 1.0; // Bipolar mode: normalize ADC value to [-REF, REF]
  } 
  else 
  {
    voltage = voltage / (double)0xFFFFFF; // Unipolar mode: normalize ADC value to [0, REF]
  }

  voltage = voltage * vref / (double)gain;  // Apply reference voltage and gain scaling
  return voltage;
}

int setAdcControl(uint8_t mode, uint8_t power, uint8_t clkSource, bool enable)
{
  uint16_t control = 0;

  control |= AD7124_ADC_CTRL_REG_MODE(mode);
  control |= AD7124_ADC_CTRL_REG_POWER_MODE(power);
  control |= AD7124_ADC_CTRL_REG_CLK_SEL(clkSource);
  if (enable) 
  {
    control |= AD7124_ADC_CTRL_REG_REF_EN;
  }
  control |= AD7124_ADC_CTRL_REG_CS_EN;
  control &= ~AD7124_ADC_CTRL_REG_DATA_STATUS; 

  uint8_t controlBytes[2] = { (uint8_t)(control >> 8), (uint8_t)(control & 0xFF) };
  return adcWrite(AD7124_ADC_CTRL_REG, controlBytes, 2);
}

int setConfig(uint8_t configNum, uint8_t reference, uint8_t gain, bool bipolar)
{
  uint16_t config = 0;
  config |= AD7124_CFG_REG_REF_SEL(reference);  // Reference source (bits 4:3)
  config |= AD7124_CFG_REG_PGA(gain); // Programmable gain (bits 2:0)

  if (bipolar)  // Bipolar/unipolar (bit 11)
  {
    config |= AD7124_CFG_REG_BIPOLAR;
  }

  config |= AD7124_CFG_REG_REF_BUFP;   // bit 8: buffer REFINx(+)
  config |= AD7124_CFG_REG_REF_BUFM;   // bit 7: buffer REFINx(–)
  config |= AD7124_CFG_REG_AIN_BUFP;   // bit 6: buffer AINP
  config |= AD7124_CFG_REG_AINN_BUFM; // bit 5: buffer AINM

  uint8_t configBytes[2] = {
    uint8_t(config >> 8),
    uint8_t(config & 0xFF)
  };
  return adcWrite(AD7124_CFG0_REG + configNum, configBytes, 2);
}

int setConfigFilter(uint8_t filterNum, uint8_t filterType, uint16_t targetSPS, bool enableRej60)
{
  uint32_t filter = 0;
  filter |= AD7124_FILT_REG_FILTER(filterType); // Sinc4 filter

  if (enableRej60) 
  {
    filter |= AD7124_FILT_REG_REJ60;  // Enable 60 Hz rejection
  }
  filter |= AD7124_FILT_REG_FS(fs);

  uint8_t filterBytes[3] = {  // Create filter configuration bytes
    (uint8_t)((filter >> 16) & 0xFF),
    (uint8_t)((filter >> 8) & 0xFF),
    (uint8_t)(filter & 0xFF)
  };

  return adcWrite(AD7124_FILT0_REG + filterNum, filterBytes, 3);  // Write the configuration to the appropriate filter register
}

int setChannel(uint8_t channelNum, uint8_t configNum, uint8_t posInput, uint8_t negInput, bool enable)
{
  uint16_t channel = 0;

  channel |= AD7124_CH_MAP_REG_SETUP(configNum);
  channel |= AD7124_CH_MAP_REG_AINP(posInput);
  channel |= AD7124_CH_MAP_REG_AINM(negInput);
  if (enable) 
  {
    channel |= AD7124_CH_MAP_REG_CH_ENABLE;
  }

  uint8_t channelBytes[2] = { (uint8_t)(channel >> 8), (uint8_t)(channel & 0xFF) };
  int status = adcWrite(AD7124_CH0_MAP_REG + channelNum, channelBytes, 2);

  Serial.printf("Channel %d set status: %d\n", channelNum, status);
  return status;
}

int enableChannel(uint8_t channelNum, bool enable)
{
  uint8_t channelBytes[2] = {0};
  int status = adcRead(AD7124_CH0_MAP_REG + channelNum, channelBytes, 2);
  if (status != 0) 
  {
    return status;
  }

  uint16_t channel = (channelBytes[0] << 8) | channelBytes[1];
  if (enable) 
  {
    channel |= AD7124_CH_MAP_REG_CH_ENABLE; // Enable the channel
  } 
  else 
  {
    channel &= ~AD7124_CH_MAP_REG_CH_ENABLE; // Disable the channel
  }

  channelBytes[0] = (uint8_t)((channel >> 8) & 0xFF);
  channelBytes[1] = (uint8_t)(channel & 0xFF);

  return adcWrite(AD7124_CH0_MAP_REG + channelNum, channelBytes, 2);
}

void ad7124_init(uint16_t target_sps)
{
  // Configure ADC control
  int status = setAdcControl(0x00, 0x03, 0x00, false); // Continuous, full power, internal clock, REF_EN = false
  Serial.printf("ADC control set status: %d\n", status);

  // Set default configuration for input channel(s)
  status = setConfig(0, 0x00, 0x01, true); // Config 0, REF1+/REF1-, Gain=1, Unipolar = False, Bipolar = True
  Serial.printf("ADC config set status: %d\n", status);

  // Calculate Filter Word (FS) for target SPS
  status = setConfigFilter(0, 0x00, target_sps, true); // Sinc4 filter with target SPS and 60Hz Notch Enabled
  Serial.printf("ADC filter set status: %d\n", status);

  // inside ad7124_init(...)
  status = setChannel(0, 0, 0x00, 0x01, true);
  Serial.printf("Channel 1 set status: %d\n", status);

  status = setChannel(1, 0, 0x02, 0x03, true);
  Serial.printf("Channel 2 set status: %d\n", status);

  status = setChannel(2, 0, 0x04, 0x05, true);
  Serial.printf("Channel 3 set status: %d\n", status);

  status = setChannel(3, 0, 0x06, 0x07, true);
  Serial.printf("Channel 4 set status: %d\n", status);
}

/******************************************
*           WiFI FUNCTIONS               *
******************************************/

void wifi_init()  // Connect to Wi-Fi 
{
  Serial.print("Connecting to Wi-Fi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    Serial.print(".");  // IF YOU SEE A SERIES OF ...... ON COMPILE, YOUR WIFI PROBABLY ISNT CONNECTED. CHECK YOUR INFO
  }
  delay(500);
  Serial.println("\nWi-Fi connected.");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
}

void checkWiFi()  // Handle Wi-Fi Reconnection  
{
  if (WiFi.status() != WL_CONNECTED) 
  {
    Serial.println("Reconnecting to Wi-Fi...");
    WiFi.disconnect();
    WiFi.reconnect();
  }
}

void init_SNTP()  // Initialize SNTP (NTP Time Sync) Will likely need to change
{
  Serial.println("Initializing SNTP Link...");
  timeClient.begin();
}

void obtain_time()  // Obtain current time from NTP server
{
  init_SNTP();
    
  int retry = 0;
  const int retry_count = 10;
    
  while (!timeClient.update() && retry < retry_count) 
  {
    Serial.printf("Waiting for TimeSync... (%d|%d)\n", retry + 1, retry_count);
    retry++;
    delay(2000);
  }

  if (retry >= retry_count) 
  {
    Serial.println("Failed to sync time!");
  }
}

void Get_current_date_time(char *date_time)
{
  time_t now = time(nullptr); // Get current system time (from RTC)
  struct tm timeinfo;
  localtime_r(&now, &timeinfo); // Convert to local time structure

  snprintf(date_time, 100, "%04d-%02d-%02d %02d:%02d:%02d",timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday, 
  timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
}

void Set_SystemTime_SNTP()
{
  const long gmtOffset_sec = -6 * 3600; // UTC-6 (Central Standard Time)
  const int daylightOffset_sec = 3600;  // Uncomment during daylight savings, comment when DST is over. 
  configTime(gmtOffset_sec, daylightOffset_sec, "pool.ntp.org", "time.nist.gov");
}

void computeAlphaCorrection() 
{
  int64_t t1 = esp_wifi_get_tsf_time(WIFI_IF_STA);
  int64_t c1 = micros();

  // keep drift rate the same as before:
  alpha = float((t1 - sync_tsf_0) - (c1 - sync_clock_0)) / 100.0f;

  // now reset your anchors:
  sync_tsf_0 = t1;
  sync_clock_0 = c1;

  // compute fresh offset so that: corrected_time = micros() + offset_us
  offset_us = sync_tsf_0 - sync_clock_0;
}

void syncClocks() 
{
  uint64_t local_start = micros();
  uint64_t tsf_now = esp_wifi_get_tsf_time(WIFI_IF_STA);
  uint64_t corrected = tsf_now + micros() - local_start;

  // align the GPTimer
  if (tsfTimer) 
  {
    ESP_ERROR_CHECK(gptimer_set_raw_count(tsfTimer, corrected));
    Serial.printf("TSF Sync successful. Timer aligned to %llu\n", corrected);
  }

  // capture initial anchors and offset
  sync_tsf_0   = tsf_now;
  sync_clock_0 = local_start;
  offset_us    = int64_t(tsf_now) - int64_t(local_start);
}

static bool IRAM_ATTR adc_timer_callback(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_ctx)
{
  static uint64_t last_interrupt_time = 0;
  uint64_t current_interrupt_time = esp_timer_get_time();
  last_interrupt_time = current_interrupt_time;
  BaseType_t high_task_awoken = pdFALSE;
  xSemaphoreGiveFromISR(adc_semaphore, &high_task_awoken);
  return high_task_awoken == pdTRUE;
}

void setup_adc_timer(uint64_t interval_us)
{
  gptimer_config_t timer_config = {
    .clk_src = GPTIMER_CLK_SRC_DEFAULT,
    .direction = GPTIMER_COUNT_UP,
    .resolution_hz = 1000000, // 1 MHz (µs resolution)
  };
  ESP_ERROR_CHECK(gptimer_new_timer(&timer_config, &adc_gptimer));

  gptimer_event_callbacks_t cbs = {
      .on_alarm = adc_timer_callback,
  };
  ESP_ERROR_CHECK(gptimer_register_event_callbacks(adc_gptimer, &cbs, NULL));
  ESP_ERROR_CHECK(gptimer_enable(adc_gptimer));

  gptimer_alarm_config_t alarm_config = {};
  alarm_config.alarm_count = interval_us;
  alarm_config.reload_count = 0;
  alarm_config.flags.auto_reload_on_alarm = true;

  ESP_ERROR_CHECK(gptimer_set_alarm_action(adc_gptimer, &alarm_config));
  ESP_ERROR_CHECK(gptimer_start(adc_gptimer));

  float actualHz = 1.0 / (interval_us * 0.000001);
  Serial.printf("ADC Sampling Frequency set to %.1f Hz\n", actualHz);
}

uint32_t getCorrectedMicros() 
{
  // base = local micros + last offset
  int64_t base = int64_t(micros()) + offset_us;
  // apply the small linear drift correction: 
  //  corrected = base + alpha * (micros() - sync_clock_0)
  int64_t delta = int64_t(micros()) - sync_clock_0;
  return uint32_t(base + delta * alpha);
}

void getTimestamp(char *buf, size_t len) 
{
  // 1) wall‐clock seconds from SNTP
  time_t now_s = time(nullptr);
  struct tm tm_s;
  localtime_r(&now_s, &tm_s);

  // 2) high-res microseconds from our corrected counter
  uint32_t t_us = getCorrectedMicros();
  uint32_t ms   = (t_us % 1000000) / 1000;

  // 3) format
  snprintf(buf, len,
           "%04d-%02d-%02d %02d:%02d:%02d",
           tm_s.tm_year + 1900,
           tm_s.tm_mon  +   1,
           tm_s.tm_mday,
           tm_s.tm_hour,
           tm_s.tm_min,
           tm_s.tm_sec);
}

/******************************************
*           MQTT FUNCTIONS               *
******************************************/

void mqttStart() 
{
  Serial.printf("Connecting to MQTT Broker at %s...\n", mqtt_server);
  
  int attempts = 0;
  while (!mqttClient.connect(mqtt_server, mqtt_port) && attempts < 1) 
  {
    Serial.printf("Attempt %d: MQTT connection failed! Error Code: %d. Retrying...\n", attempts + 1, mqttClient.connectError());
    attempts++;
    delay(1000);
  }

  if (mqttClient.connected()) 
  {
    Serial.println("Connected to MQTT Broker!");
    mqttConnected = true;

    mqttClient.subscribe("esp32/sensor/data/S1");     
    mqttClient.subscribe("esp32/sensor/settings");

    mqttClient.onMessage(onMqttMessage); // <-- Add this line to register callback
  } 
  else 
  {
    Serial.println("MQTT connection failed after multiple attempts!");
  }
}

void mqttPublish(int channel, double voltage) 
{
  if (!mqttConnected) 
  {
    Serial.println("MQTT not connected, skipping publish");
    return;
  }

  char message[50];
  snprintf(message, sizeof(message), "%d: %g", channel, voltage);

  mqttClient.beginMessage("esp32/sensor/data/S1");
  mqttClient.print(message);
  mqttClient.endMessage();
}

void mqttReconnect() 
{
  if (WiFi.status() == WL_CONNECTED && !mqttConnected) 
  {
    Serial.println("Attempting MQTT reconnection...");
    if (mqttClient.connect(mqtt_server, mqtt_port)) 
    {
      Serial.println("MQTT reconnected successfully!");
      mqttConnected = true;
      mqttClient.subscribe("esp32/sensor/data/S1");
      mqttClient.subscribe("esp32/sensor/settings"); // Ensure to resubscribe here
      mqttClient.onMessage(onMqttMessage);           // Re-register callback here
      mqttReconnectTicker.detach(); 
    } 
    else 
    {
      Serial.printf("MQTT reconnect failed! Error Code: %d\n", mqttClient.connectError());
    }
  }
}

void onMqttMessage(int messageSize) 
{
  String topic = mqttClient.messageTopic();
  String payload = "";
  
  while (mqttClient.available()) 
  {
    payload += (char)mqttClient.read();
  }

  //Serial.printf("Message received on topic '%s': %s\n", topic.c_str(), payload.c_str());

  if (topic == "esp32/sensor/settings") 
  {
    int newFs = payload.toInt();
    if (newFs == 48 || newFs == 19)  // validate allowed values explicitly
    {  
      Serial.printf("Requested new Fs received: %d\n", newFs);
      newRequestedFs = newFs;                 // Set new frequency request
      freqChangeRequested = true;             // Set flag to trigger ADC reset/reconfig
    } 
    else 
    {
      Serial.println("Invalid Fs received!");
    }
  }
}

/******************************************
*            SETUP & MAIN LOOP           *
******************************************/

void updateSamplingFrequency(int newFs)
{
  delay(100);
  Serial.printf("Updating ADC sampling frequency to %d Hz\n", newFs);

  if (adc_gptimer) {
    ESP_ERROR_CHECK(gptimer_stop(adc_gptimer));
    ESP_ERROR_CHECK(gptimer_disable(adc_gptimer));
    ESP_ERROR_CHECK(gptimer_del_timer(adc_gptimer));
    adc_gptimer = NULL;
  }
  delay(50);

  for (int i = 0; i < NUM_CHANNELS; i++)  
  {
    // Clear the ring buffer by resetting head and tail
    ringHead[i] = 0;
    ringTail[i] = 0;
    blockIndex[i] = 0;
  }
  delay(50);

  ADC_reset();
  delay(50);
  ad7124_init(newFs);
  delay(50);

  const double f_master = 614400.0;
  double fADC = f_master / (32.0 * newFs);
  int enabled_channels = 4;
  double per_channel_sps = fADC / enabled_channels;
  uint64_t new_interval_us = (uint64_t)(1000000.0 / per_channel_sps);

  setup_adc_timer(new_interval_us);
  Serial.println("ADC sampling frequency updated successfully!");
}
static int32_t firstSample[NUM_CHANNELS];
// globals, set these once after your SNTP/TSF sync
uint64_t lastSyncEpochMs = 0;
uint32_t lastSyncMillis  = 0;

// call this right after your initial time sync in setup():
void recordSyncTimestamp() 
{
  lastSyncEpochMs = uint64_t(time(nullptr)) * 1000ULL;
  lastSyncMillis  = millis();
}

// unified helper, returns nothing but writes "YYYY-MM-DD HH:MM:SS,mmm" into buf
void getSyncedDateTimeMs(char *buf, size_t len) 
{
  // 1) compute epoch‐ms from sync + elapsed
  uint64_t nowEpochMs = lastSyncEpochMs + (millis() - lastSyncMillis);

  // 2) split into secs + ms
  uint16_t ms      = nowEpochMs % 1000;
  time_t   secs    = nowEpochMs / 1000;
  struct tm tm_s;
  localtime_r(&secs, &tm_s);

  // 3) format in one go
  snprintf(buf, len,
           "%04d-%02d-%02d %02d:%02d:%02d,%03u",
           tm_s.tm_year + 1900,
           tm_s.tm_mon  +   1,
           tm_s.tm_mday,
           tm_s.tm_hour,
           tm_s.tm_min,
           tm_s.tm_sec,
           ms);
}

// ——— Globals (somewhere at top of your .ino) ———
static time_t lastSec          = 0;    // tracks the last-second boundary
static uint32_t secStartMillis = 0;    // millis() at the moment the second rolled over

// ——— New helper ———
// Fills buf with "YYYY-MM-DD HH:MM:SS" and returns the millisecond offset [0–999+] 
// since the start of that second.
uint16_t getTimestampResetMs(char *buf, size_t len) 
{
  // 1) Get current wall-clock second
  time_t nowSec = time(nullptr);
  struct tm tm_s;
  localtime_r(&nowSec, &tm_s);

  // 2) If the second changed, reset our millisecond timer
  if (nowSec != lastSec) {
    lastSec = nowSec;
    secStartMillis = millis();
  }

  // 3) Compute ms since the top of this second
  uint32_t elapsed = millis() - secStartMillis;
  uint16_t ms = elapsed % 1000;  // keep within 0–999

  // 4) Format "YYYY-MM-DD HH:MM:SS"
  snprintf(buf, len,
           "%04d-%02d-%02d %02d:%02d:%02d",
           tm_s.tm_year + 1900,
           tm_s.tm_mon  +   1,
           tm_s.tm_mday,
           tm_s.tm_hour,
           tm_s.tm_min,
           tm_s.tm_sec);

  return ms;
}


void processBufferedData() 
{
  char openlogTs[32];
  char mqttTs[32];
  char line[80];

  for (uint8_t ch = 0; ch < NUM_CHANNELS; ++ch) 
  {
    while (ringTail[ch] != ringHead[ch]) 
    {
      // — Pull and compress raw sample —
      int32_t raw = adcRingBuffer[ch][ringTail[ch]];
      ringTail[ch] = (ringTail[ch] + 1) % RING_BUFFER_SIZE;

      int32_t val;
      if (blockIndex[ch] == 0) {
        firstSample[ch] = raw;
        val = raw;
      } else {
        int32_t d = raw - firstSample[ch];
        d = constrain(d, -127, 127);
        val = firstSample[ch] + d;
      }
      if (++blockIndex[ch] >= BLOCK_SIZE) blockIndex[ch] = 0;

      //Serial.print(ch+1);
      //Serial.print(" ");
      //Serial.println(raw);
      // — Voltage conversion —
      //double voltage = calibratedVoltage(ch, val);
      double voltage = toVoltage(raw,1,1.8,true);

      // — OpenLog with second‐precision —
      Get_current_date_time(openlogTs);
      snprintf(line, sizeof(line), "%s,%u,%.6f\n",
               openlogTs,
               (uint8_t)(ch + 1),
               voltage);
      toOpenlog(line);

      uint16_t ms = getTimestampResetMs(mqttTs, sizeof(mqttTs));
      snprintf(line, sizeof(line), "%s.%03u,%u,%.6f", mqttTs, ms, (uint8_t)(ch+1), voltage);

      //Serial.print("MQTT→ ");
      //Serial.println(mqttTs);

      if (mqttConnected) {
        mqttClient.beginMessage("esp32/sensor/data/S1");
        mqttClient.print(line);
        mqttClient.endMessage();
      }

      delayMicroseconds(5);
    }
  }
}

void setup() 
{
  Serial.begin(115200);
  delay(500);
  ADC_reset();

  // ─── Wi‑Fi, NTP, MQTT, SPI, ADC, OpenLog ───
  wifi_init();
  delay(2000);

  Set_SystemTime_SNTP();
  delay(50);

  mqttStart();
  delay(50);

  spi_init();
  delay(50);

  ADC_reset();
  delay(50);

  ad7124_init(fs);

  //runFourPointCalibration(/*samplesPerPoint=*/32, /*intervalMs=*/50);
  //Serial.println("Paste that CSV into Excel, then reflash with your calibrated slope/intercept!");

  reset_openlog();
  openlog_uart_init();

  Serial.println("wDABS Setup Complete!");

  // ─── ADC Sampling GPTimer ───
  const double f_master         = 614400.0;
  double       fADC             = f_master / (32.0 * fs);
  int          enabled_channels = NUM_CHANNELS;
  double       per_channel_sps  = fADC / enabled_channels;
  uint64_t     sample_period_us = (uint64_t)(1e6 / per_channel_sps);

  adc_semaphore = xSemaphoreCreateBinary();
  setup_adc_timer(sample_period_us);
  last_time     = micros();

  // ─── TSF‑Aligned GPTimer ───
  {
    gptimer_config_t tsf_cfg = {
      .clk_src       = GPTIMER_CLK_SRC_DEFAULT,
      .direction     = GPTIMER_COUNT_UP,
      .resolution_hz = 1000000  // 1 MHz → 1 µs ticks
    };
    ESP_ERROR_CHECK(gptimer_new_timer(&tsf_cfg, &tsfTimer));
    ESP_ERROR_CHECK(gptimer_enable(tsfTimer));
    ESP_ERROR_CHECK(gptimer_start(tsfTimer));
  }

  syncClocks(); // initial TSF sync
  sync_tsf_0   = esp_wifi_get_tsf_time(WIFI_IF_STA);
  sync_clock_0 = micros();
  recordSyncTimestamp();
}

void loop() 
{

  if (freqChangeRequested)  // Handle any requested sampling frequency change
  {
    freqChangeRequested = false;
    updateSamplingFrequency(newRequestedFs);
  }

  if (xSemaphoreTake(adc_semaphore, portMAX_DELAY)) // Wait for ADC timer interrupt (via semaphore), then read & publish 
  {
    readAndBufferData();
    processBufferedData();
  }

  static int alpha_count = 0; // Every 100 blocks, recompute drift‐correction alpha
  if (++alpha_count >= 200) 
  {
    computeAlphaCorrection();
    alpha_count = 0;
  }

  mqttClient.poll();  // Poll the MQTT client (NEED TO CHANGE)
}