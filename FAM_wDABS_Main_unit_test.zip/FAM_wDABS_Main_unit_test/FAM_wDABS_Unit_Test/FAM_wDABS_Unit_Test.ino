#include <Arduino.h>       // Standard Arduino core
#include <SPI.h>           // SPI library 
#include <WiFi.h>          // WiFi support
#include <ArduinoMqttClient.h>
#include <HardwareSerial.h> // For UART (OpenLog)
#include "../FAM_wDABS_Main/AD_Defs.h"       // ADC Definitions 
#include <WiFiUdp.h>
#include <NTPClient.h>
#include <Ticker.h>
#include <FreeRTOS.h> 
#include <semphr.h>
#include <vector>
#include <queue>
#include <AUnit.h>


#include "../FAM_wDABS_Main/FAM_wDABS_Main.ino"

using namespace aunit;


/*******************************
*      UART TEST FUNCTIONS     *
*******************************/


test(test_openlog_uart_init) // running test for openlog_uart_init
{
  test_flag = 0;  // setting test flag to 0
  openlog_uart_init();  // running openlog_uart_init function
  assertTrue(test_flag);  // checking if flag is set
  test_flag = 0;
}


test(test_reset_openlog)
{
  test_flag = 0;  // setting test flag to 0
  reset_openlog(); // running reset_openlog function
  assertTrue(test_flag); // checking if flag is set
  test_flag = 0;
}

test(test_log_to_openlog)
{
  // setup for log_to_openlog test
  test_flag = 0;
  char log_test1[150];  // log test for channel 1
  char log_test2[150];  // log test for channels 2-4
  char log_test3[150];
  char log_test4[150];

  int32_t adcTestValue = adcBuffer[0].front();
  uint8_t compressed_data_test[4];
  
  Get_current_date_time(Current_Date_Time);
  
  compressed_data_test[1] = (adcTestValue >> 16) & 0xFF;
  compressed_data_test[2] = (adcTestValue >> 8) & 0xFF;
  compressed_data_test[3] = adcTestValue & 0xFF;

  double testVoltage = toVoltage(adcTestValue, 1, 3.0, true);

  // channel 1
  snprintf(log_test1, sizeof(log_test1), "%s, CH%d, %02X %02X %02X, %.6f V\n", 
  Current_Date_Time, 1, compressed_data_test[1], compressed_data_test[2], compressed_data_test[3], testVoltage);
  // channel 2
  snprintf(log_test2, sizeof(log_test2), "%s, CH%d, %02X, %.6f V\n", 
  Current_Date_Time, 2, compressed_data_test[1], testVoltage);
  // channel 3
  snprintf(log_test3, sizeof(log_test3), "%s, CH%d, %02X, %.6f V\n", 
  Current_Date_Time, 3, compressed_data_test[1], testVoltage);
  // channel 4
  snprintf(log_test4, sizeof(log_test4), "%s, CH%d, %02X, %.6f V\n", 
  Current_Date_Time, 4, compressed_data_test[1], testVoltage);

  // running test

  // channel 1
  log_to_openlog(log_test1);
  assertTrue(test_flag);
  test_flag = 0;

  // channel 2
  log_to_openlog(log_test2);
  assertTrue(test_flag);
  test_flag = 0; 

  // channel 3
  log_to_openlog(log_test3);
  assertTrue(test_flag);
  test_flag = 0;

  // channel 4

  log_to_openlog(log_test4);
  assertTrue(test_flag);
  test_flag = 0;
}

/**********************************************
*          SPI CONFIG TEST FUNCTIONS          *
**********************************************/

test(test_spi_init) // testing spi_init function
{
  test_flag = 0;
  spi_init();
  assertTrue(test_flag);
  test_flag = 0;
}

test(test_spiRead_success) // testing spiRead function
{
  uint8_t txBuffer[1] = {AD7124_COMM_REG_RD | AD7124_COMM_REG_RA(AD7124_DATA_REG)};
  uint8_t rxBuffer[4] = {0}; 

  assertEqual(spiRead(txBuffer, rxBuffer, sizeof(rxBuffer)), 0);
}

test(test_spiWrite_reset) // testing spiWrite function for reseting ADC
{
  uint8_t txBuffer[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
   
  assertEqual(spiWrite(txBuffer, sizeof(txBuffer)), 0);
}

test(test_spiWrite_acdwrite) // testing spiWrite function for writing buffer over SPI
{
  // setup for data
  uint16_t testControl1 = 0;

  // setup for enable bit set to true
  testControl1 |= AD7124_ADC_CTRL_REG_MODE(0x00);
  testControl1 |= AD7124_ADC_CTRL_REG_POWER_MODE(0x03);
  testControl1 |= AD7124_ADC_CTRL_REG_CLK_SEL(0x00);
  testControl1 |= AD7124_ADC_CTRL_REG_REF_EN;
  testControl1 |= AD7124_ADC_CTRL_REG_CS_EN;

  uint8_t data[2] = { (uint8_t)(testControl1 >> 8), (uint8_t)(testControl1 & 0xFF) };

  uint8_t reg = AD7124_ADC_CTRL_REG;
  size_t len = 2;
  uint8_t txBuffer[len + 1];
  txBuffer[0] = AD7124_COMM_REG_WR | AD7124_COMM_REG_RA(reg);
  memcpy(&txBuffer[1], data, len); 

  assertEqual(spiWrite(txBuffer, len + 1), 0);
}

/************************************************
*           MQTT TEST FUNCTIONS                 *
**************************Current_Date_Time**********************/

/*      MQTT_START TESTS            */

test(test_mqtt_start_success)  // testing for mqtt client init success
{
  test_flag = 0;
  mqttStart();
  assertTrue(test_flag);
  test_flag = 0;
}

test(test_mqtt_start_fail) // testing for mqtt client init Fail
{
  test_flag = 0;
  mqttStart();
  assertTrue(test_flag);
  test_flag = 0;
}

/*      MQTT_PUBLISH_ TESTS        */

test(test_mqtt_Publish_success) // testing mqttPublish function for successful mqtt connection
{
  mqttConnected = true;

  // channel 1
  test_flag = 0;
  mqttPublish(1,1.0);
  assertTrue(test_flag);
  
  // channel 2
  test_flag = 0;
  mqttPublish(2,1.0);
  assertTrue(test_flag);
  
  // channel 3
  test_flag = 0;
  mqttPublish(3,1.0);
  assertTrue(test_flag);
  
  // channel 4 
  test_flag = 0;
  mqttPublish(4,1.0);
  assertTrue(test_flag);

  test_flag = 0;
  mqttConnected = false;
}

test(test_mqtt_Publish_fail) // testing mqttPublish function for failed mqtt connection
{
  test_flag2 = 0;
  mqttConnected = false;

  mqttPublish(1,1.0);
  assertTrue(test_flag2);
  test_flag2 = 0;
}

/************************************************
*           SNTP/DATE & TIME TEST FUNCTIONS                 *
************************************************/

/*      INIT_SNTP TESTS     */

test(test_init_SNTP)  // testing init_SNTP function
{
  test_flag = 0;
  init_SNTP();
  assertTrue(test_flag);
  test_flag = 0;
}

/*      OBTAIN_TIME TESTS   */

test(test_obtain_time) // testing obtain_time function
{
  test_flag = 0;
  test_flag2 = 0;
  
  obtain_time();
  assertTrue(test_flag); // testing for successful Timesync
  assertTrue(test_flag2); // testing for Unsuccessful Timesync
  
  test_flag = 0;
  test_flag2 = 0;
}

test(test_Get_currrent_date_time) // testing Get_currrent_date_time fucntion 
{
  test_flag = 0;
  Get_current_date_time(Current_Date_Time);
  assertTrue(test_flag);
  test_flag = 0;
}

test(test_Set_SystemTime_SNTP) // testing Set_SystemTime_SNTP fucntion 
{
  test_flag = 0;
  Set_SystemTime_SNTP();
  assertTrue(test_flag);
  test_flag = 0;
}

/*      ADC_TIMER TESTS   */

test(test_setup_adc_timer) // testing setup_adc_timer function
{
  test_flag = 0;

  const double f_master = 614400.0; 
  double fADC = f_master / (32.0 * fs);   
  int enabled_channels = 4;  
  double per_channel_sps = fADC / enabled_channels; 
  uint64_t sample_period_us = (uint64_t)(1000000.0 / per_channel_sps);
  adc_semaphore = xSemaphoreCreateBinary(); // Set the ADC Semaphore
  setup_adc_timer(sample_period_us); // ADC Timer for testing sampling speed
  
  assertTrue(test_flag);
  test_flag = 0;
}

test(test_adc_timer_callback) // testing adc_timer_callback function 
{
  test_flag = 0;

  const double f_master = 614400.0; 
  double fADC = f_master / (32.0 * fs);   
  int enabled_channels = 4;  
  double per_channel_sps = fADC / enabled_channels; 
  uint64_t sample_period_us = (uint64_t)(1000000.0 / per_channel_sps);
  adc_semaphore = xSemaphoreCreateBinary(); // Set the ADC Semaphore
  
  adcTimer.attach_us(sample_period_us, adc_timer_callback); // Set periodic timer
  assertTrue(test_flag);
  test_flag = 0;
}

/********************************************
*           ADC CONTROL FUNCTIONS TEST      *
********************************************/

test(test_ADC_reset) // testing adc reset
{
  test_flag = 0;
  ADC_reset();
  assertTrue(test_flag);
  test_flag = 0;
}

/*      ADC WRITE TESTS     */

// testing calls from set control/config/configFilter/setChannel/enable channel

test(test_adcWrite_control) // testing adcwrite from control input 
{
  uint16_t testControl1 = 0, testControl2 = 0;
  // setup for enable bit set to true
  testControl1 |= AD7124_ADC_CTRL_REG_MODE(0x00);
  testControl1 |= AD7124_ADC_CTRL_REG_POWER_MODE(0x03);
  testControl1 |= AD7124_ADC_CTRL_REG_CLK_SEL(0x00);
  testControl1 |= AD7124_ADC_CTRL_REG_REF_EN;
  testControl1 |= AD7124_ADC_CTRL_REG_CS_EN;

  // setup for enable bit set to false
  testControl2 |= AD7124_ADC_CTRL_REG_MODE(0x00);
  testControl2 |= AD7124_ADC_CTRL_REG_POWER_MODE(0x03);
  testControl2 |= AD7124_ADC_CTRL_REG_CLK_SEL(0x00);
  testControl2 |= AD7124_ADC_CTRL_REG_CS_EN;


  uint8_t testControlBytes1[2] = { (uint8_t)(testControl1 >> 8), (uint8_t)(testControl1 & 0xFF) };
  uint8_t testControlBytes2[2] = { (uint8_t)(testControl2 >> 8), (uint8_t)(testControl2 & 0xFF) };
  
  assertEqual(adcWrite(AD7124_ADC_CTRL_REG, testControlBytes1, 2), 0); // testing with REF enabled
  assertEqual(adcWrite(AD7124_ADC_CTRL_REG, testControlBytes2, 2), 0); // testing with REF disabled
}


test(test_adcWrite_config)  // testing adcwrite from Config input
{
  uint16_t testConfig1 = 0, testConfig2 = 0;
  // setup for bipolar mode
  testConfig1 |= AD7124_ADC_CTRL_REG_MODE(0x00);
  testConfig1 |= AD7124_ADC_CTRL_REG_POWER_MODE(0x00);
  testConfig1 |= AD7124_CFG_REG_BIPOLAR;
  
  // setup for disabled bipolar mode
  testConfig2 |= AD7124_ADC_CTRL_REG_MODE(0x00);
  testConfig2 |= AD7124_ADC_CTRL_REG_POWER_MODE(0x00);


  uint8_t testConfigBytes1[2] = { (uint8_t)(testConfig1 >> 8), (uint8_t)(testConfig1 & 0xFF) };
  uint8_t testConfigBytes2[2] = { (uint8_t)(testConfig2 >> 8), (uint8_t)(testConfig2 & 0xFF) };
  
  assertEqual(adcWrite(AD7124_CFG0_REG + 0, testConfigBytes1, 2), 0); // testing with bipolar mode enabled
  assertEqual(adcWrite(AD7124_CFG0_REG + 0, testConfigBytes2, 2), 0); // testing with bipolar mode disabled
}


test(test_adcWrite_configFilter)  // testing adcwrite from ConfigFilter input 
{
  uint16_t testFilter1 = 0, testFilter2 = 0;
  // setup for enable 60 hz rejection
  testFilter1 |= AD7124_FILT_REG_FILTER(0x00);
  testFilter1 |= AD7124_FILT_REG_FS(fs);
  testFilter1 |= AD7124_FILT_REG_REJ60;
  
  // setup for disable 60 hz rejection
  testFilter2 |= AD7124_FILT_REG_FILTER(0x00);
  testFilter2 |= AD7124_FILT_REG_FS(fs);

  // setting up filter config bytes
  uint8_t testFilterBytes1[3] = {
    (uint8_t)((testFilter1 >> 16) & 0xFF), 
    (uint8_t)((testFilter1 >> 8) & 0xFF), 
    (uint8_t)(testFilter1 & 0xFF)
  };
  
  uint8_t testFilterBytes2[3] = {
    (uint8_t)((testFilter2 >> 16) & 0xFF), 
    (uint8_t)((testFilter2 >> 8) & 0xFF), 
    (uint8_t)(testFilter2 & 0xFF)
  };  
  
  assertEqual(adcWrite(AD7124_FILT0_REG + 0, testFilterBytes1, 3), 0); // testing with 60 Hz rejection enabled
  assertEqual(adcWrite(AD7124_FILT0_REG + 0, testFilterBytes2, 3), 0); // testing with 60 Hz rejection disabled
}

test(test_adcWrite_setChannel)  // testing adcwrite from set channel input
{
  uint16_t testChannel1 = 0, testChannel2 = 0;

  // setup for test channel with enable
  testChannel1 |= AD7124_CH_MAP_REG_SETUP(0);
  testChannel1 |= AD7124_CH_MAP_REG_AINP(0x00);
  testChannel1 |= AD7124_CH_MAP_REG_AINM(0x01);
  testChannel1 |= AD7124_CH_MAP_REG_CH_ENABLE;
  
  // setup for test channel without enable
  testChannel2 |= AD7124_CH_MAP_REG_SETUP(0);
  testChannel2 |= AD7124_CH_MAP_REG_AINP(0x00);
  testChannel2 |= AD7124_CH_MAP_REG_AINM(0x01);

  uint8_t testChannelBytes1[2] = { (uint8_t)(testChannel1 >> 8), (uint8_t)(testChannel1 & 0xFF) };
  uint8_t testChannelBytes2[2] = { (uint8_t)(testChannel2 >> 8), (uint8_t)(testChannel2 & 0xFF) };


  assertEqual(adcWrite(AD7124_CH0_MAP_REG + 0, testChannelBytes1, 2), 0); // testing with channel enable
  assertEqual(adcWrite(AD7124_CH0_MAP_REG + 0, testChannelBytes2, 2), 0); // testing without channel enable
}


test(test_adcWrite_enableChannel) 
{
  uint16_t testChannel1 = 0, testChannel2 = 0;

  // setup for test channel with enable
  testChannel1 |= AD7124_CH_MAP_REG_CH_ENABLE;
  
  // setup for test channel diable
  testChannel2 |= AD7124_CH_MAP_REG_SETUP(0);
  testChannel2 |= AD7124_CH_MAP_REG_AINP(0x00);
  testChannel2 |= AD7124_CH_MAP_REG_AINM(0x01);

  uint8_t testChannelBytes1[2] = { (uint8_t)(testChannel1 >> 8), (uint8_t)(testChannel1 & 0xFF) };
  uint8_t testChannelBytes2[2] = { (uint8_t)(testChannel2 >> 8), (uint8_t)(testChannel2 & 0xFF) };


  assertEqual(adcWrite(AD7124_CH0_MAP_REG + 0, testChannelBytes1, 2), 0); // testing with channel enable
  assertEqual(adcWrite(AD7124_CH0_MAP_REG + 0, testChannelBytes2, 2), 0); // testing without channel enable
  
}

/*      ADC READ TESTS     */

test(test_adcRead)  // testing adcRead function
{
  uint8_t status = 0;
  uint8_t testChannelBytes[2] = {0};

  assertEqual(adcRead(AD7124_STATUS_REG, &status, 1), 0); // used in readAndBufferData()
  assertEqual(adcRead(AD7124_CH0_MAP_REG + 1, testChannelBytes, 2), 0); // used in enableChannel() 
}

test(test_toVoltage) // testing toVoltage function
{
  int32_t adcValue = 0.0;

  // testing with bipolar mode
  assertNear(toVoltage(adcValue,1,3.0,true), -3.0, 0.0001);

  // testing without bipolar mode 
  assertNear(toVoltage(adcValue,1,3.0,false), 0.0, 0.0001);
}

test(test_setAdcControl) // testing adc control setup
{
  assertEqual(setAdcControl(0x00, 0x03, 0x00, false), 0);
}

test(test_setConfig) // testing adc configuration
{
  assertEqual(setConfig(0, 0x00, 0x00, true), 0);
}

test(test_setFilterConfig) // testing Filter Configuration
{
  assertEqual(setConfig(0, 0x00, 18, true), 0);
}

test(test_setChannel) // testing channel set up for channels 0 - 3
{
  assertEqual(setChannel(0, 0, 0x00, 0x01, true), 0); // channel 0: (AIN0 & AIN1)
  assertEqual(setChannel(1, 0, 0x02, 0x03, true), 0); // channel 1: (AIN2 & AIN3)
  assertEqual(setChannel(2, 0, 0x04, 0x05, true), 0); // channel 2: (AIN4 & AIN5)
  assertEqual(setChannel(3, 0, 0x06, 0x07, true), 0); // channel 3: (AIN6 & AIN7)
}

test(test_enableChannel) // testing channel enable
{
  assertEqual(enableChannel(0, true), 0); // enabling channels
  assertEqual(enableChannel(1, true), 0);
  assertEqual(enableChannel(2, true), 0);
  assertEqual(enableChannel(3, true), 0);
  
  assertEqual(enableChannel(0, false), 0); // disabling channels
  assertEqual(enableChannel(1, false), 0);
  assertEqual(enableChannel(2, false), 0);
  assertEqual(enableChannel(3, false), 0);
}

test(test_ad7124_init) // testing adc initialization
{
  test_flag = 0;
  uint16_t fs1 = 18;
  uint16_t fs2 = 48;
  
  // testing with 250Hz
  ad7124_init(fs1);
  assertTrue(test_flag);
  test_flag = 0;

  // testing with 100Hz
  ad7124_init(fs2);
  assertTrue(test_flag);
  test_flag = 0;
}

/*********************************************
*            WIFI FUNCTIONS TEST             *
*********************************************/

test(test_wifi_init) // testing Wi-Fi initialization
{
  test_flag = 0;
  wifi_init();
  assertTrue(test_flag);
  test_flag = 0;
}

test(test_checkWiFi) // testing Wi-Fi Reconnection
{
  test_flag = 0;
  checkWiFi();
  assertTrue(test_flag);
  test_flag = 0; 
}

/************************************************
*           MAIN TEST FUNCTIONS                 *
************************************************/

test(test_processBufferedData)  // testing processBufferedData function
{
  test_flag = 0;
  processBufferedData();
  assertTrue(test_flag);
  test_flag = 0;
}

test(test_readAndBufferData)  // testing readAndBufferData function
{
  test_flag = 0;
  readAndBufferData();
  assertTrue(test_flag);
  test_flag = 0;
}

/************************************************
*           SETUP & LOOP FUNCTIONS              *
************************************************/

// setting function to initialize serial communication and AUnit
void setup() {
  Serial.begin(115200); // initializing serial communication at 115200 baud 
  delay(2000);  // two second delay
  TestRunner::run(); // running tests      
}

// loop to continuously run tests
void loop() {
  
}